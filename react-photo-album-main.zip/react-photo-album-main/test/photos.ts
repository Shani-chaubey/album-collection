const photos = [
    {
        src: "https://source.unsplash.com/8gVv6nxq6gY/1080x780",
        width: 1080,
        height: 800,
    },
    {
        src: "https://source.unsplash.com/Dhmn6ete6g8/1080x1620",
        width: 1080,
        height: 1620,
    },
    {
        src: "https://source.unsplash.com/RkBTPqPEGDo/1080x720",
        width: 1080,
        height: 720,
    },
    {
        src: "https://source.unsplash.com/Yizrl9N_eDA/1080x721",
        width: 1080,
        height: 721,
    },
    {
        src: "https://source.unsplash.com/KG3TyFi0iTU/1080x1620",
        width: 1080,
        height: 1620,
    },
    {
        src: "https://source.unsplash.com/Jztmx9yqjBw/1080x607",
        width: 1080,
        height: 607,
    },
    {
        src: "https://source.unsplash.com/-heLWtuAN3c/1080x608",
        width: 1080,
        height: 608,
    },
    {
        src: "https://source.unsplash.com/xOigCUcFdA8/1080x720",
        width: 1080,
        height: 720,
    },
    {
        src: "https://source.unsplash.com/1azAjl8FTnU/1080x1549",
        width: 1080,
        height: 1549,
    },
    {
        src: "https://source.unsplash.com/ALrCdq-ui_Q/1080x720",
        width: 1080,
        height: 720,
    },
    {
        src: "https://source.unsplash.com/twukN12EN7c/1080x694",
        width: 1080,
        height: 694,
    },
    {
        src: "https://source.unsplash.com/9UjEyzA6pP4/1080x1620",
        width: 1080,
        height: 1620,
    },
    {
        src: "https://source.unsplash.com/sEXGgun3ZiE/1080x720",
        width: 1080,
        height: 720,
    },
    {
        src: "https://source.unsplash.com/S-cdwrx-YuQ/1080x1440",
        width: 1080,
        height: 1440,
    },
    {
        src: "https://source.unsplash.com/q-motCAvPBM/1080x1620",
        width: 1080,
        height: 1620,
    },
    {
        src: "https://source.unsplash.com/Xn4L310ztMU/1080x810",
        width: 1080,
        height: 810,
    },
    {
        src: "https://source.unsplash.com/ls94iFAQerE/1080x1620",
        width: 1080,
        height: 1620,
    },
    {
        src: "https://source.unsplash.com/X48pUOPKf7A/1080x160",
        width: 1080,
        height: 160,
    },
    {
        src: "https://source.unsplash.com/GbLS6YVXj0U/1080x810",
        width: 1080,
        height: 810,
    },
    {
        src: "https://source.unsplash.com/9CRd1J1rEOM/1080x720",
        width: 1080,
        height: 720,
    },
    {
        src: "https://source.unsplash.com/xKhtkhc9HbQ/1080x1440",
        width: 1080,
        height: 1440,
    },
];

export default photos;
