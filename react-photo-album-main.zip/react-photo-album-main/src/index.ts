import PhotoAlbum from "./PhotoAlbum";

export * from "./types";

export { PhotoAlbum };
export default PhotoAlbum;
